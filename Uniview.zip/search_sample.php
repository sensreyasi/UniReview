<html>


<link rel="stylesheet" href="mystyle.css">
<link rel="stylesheet" href="card_style.css">

<div class="flex-container">
  <div class="left-side">
  	<div class="avatar-img">SR</div>
    <div class="student-name">Student Reviewer</div>
  </div>
  <div class="right-side">
	  <div>University Name</div>
      <div>Department Name</div>
      <p>It’s been a tough year, I have not had in person taught content since March 9th 2020, and then spend the following months recovering from a tough bout of covid. The assignments have been of a good interesting standard, however the lectures have become quite unengaging.</P>
  </div>
</div>


</html>