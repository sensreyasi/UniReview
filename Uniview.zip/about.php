<!DOCTYPE html>
<html>
<head>
  <title>Unireview</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="mystyle.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<div class="header">
  <a href="index.html" class="logo">UniView</a>
  <div class="header-right">
    <a class="" href="index.html">Home</a>
    <a href="gallery.html">Gallery</a>
    <a href="contact.html">Contact</a>
    <a class="active" href="#">About us</a>
    <button class="btn login">log in</button>
<button class="btn signup">sign up</button>

  </div>
</div>

<section >
  <div style="padding-left: 20px;">
    <h1>About us</h1> <hr>
  </div>

  <div style="padding-left: 20px;">
    <p>
           From the moment you start thinking about university from admission to right through the graduation ceremony, you think  about what university will be by your side, giving you the advice and help for the career that suits you the best.
      From finding the right course and reading honest student reviews to sound advice on everything from applications to accommodation - we have all you need to find your perfect university and make the most of it once you are there.
      You will get to know about the course content,and review for this particular course,also get to know how you can do good with a course under a selected faculty,you can find the best teacher for your field of interest here in a minute.
    </p>
    <p>
           From the moment you start thinking about university from admission to right through the graduation ceremony, you think  about what university will be by your side, giving you the advice and help for the career that suits you the best.
      From finding the right course and reading honest student reviews to sound advice on everything from applications to accommodation - we have all you need to find your perfect university and make the most of it once you are there.
      You will get to know about the course content,and review for this particular course,also get to know how you can do good with a course under a selected faculty,you can find the best teacher for your field of interest here in a minute.
    </p>
    <p>
           From the moment you start thinking about university from admission to right through the graduation ceremony, you think  about what university will be by your side, giving you the advice and help for the career that suits you the best.
      From finding the right course and reading honest student reviews to sound advice on everything from applications to accommodation - we have all you need to find your perfect university and make the most of it once you are there.
      You will get to know about the course content,and review for this particular course,also get to know how you can do good with a course under a selected faculty,you can find the best teacher for your field of interest here in a minute.
    </p>
    <hr>
  </div>
</section>

<div class="footer">
  <p>A Platform for Students <br>
    ©Unireview</p>
</div>

</body>
</html>
