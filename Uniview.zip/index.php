<?php

include 'header.php';
?>
<!-- search box -->
<form action="search_result.php" method="POST">
<div class="wrap">
  <div class="search">
    
     
     <input type="text" name="search" class="searchTerm" placeholder="What are you looking for?">
     <button type="submit" name="submit-search" class="searchButton">
       <i class="fa fa-search"></i>
    </button>
     
     
    
    
  </div>
</div>
</form>

</div>

  </div>

  

<div class="padd" ></div>
  
<div class="card-details">

 
 <button onclick="document.location='review.php'">write a Review</button>
 


  </div>

<?php


  
    

    //$search=mysqli_real_escape_string($conn,$result);
    $sql="SELECT * from review  ";
    $result2 = mysqli_query($db, $sql);
    $row_count=mysqli_num_rows($result2);
    if (mysqli_num_rows($result2) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result2))
         
            {
                
                echo "
                <link rel='stylesheet' href='mystyle.css'>
                <link rel='stylesheet' href='card_style.css'>
                <div class='flex-container'>
                  <div class='left-side'>
                      <div class='avatar-img'>".$row['rev_name']."</div>
                    <div class='student-name'>".$row['rev_name']."<br></div>
                  </div>
                  <div class='right-side'>
                      <div>".$row['uni_name']."</div>
                      <div>".$row['dept_name']."</div>
                      <p>".$row['details']."</P>
                  </div>
                </div>
                ";
               
            }
        }
        

   
?>
<!--Start of Tawk.to Script-->
<?php
include 'footer.php';
?>

</body>
</html>

