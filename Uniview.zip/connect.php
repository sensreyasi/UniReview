<?php
$servername="localhost";
$username="root";
$password="";
$db="uniview";
$conn = mysqli_connect($servername,$username,$password,$db);

if(!$conn)
{
    die("connection failed".mysqli_connect());


}

//echo 'connected succesfully';



?>

